[Drumroll plz]
Thank you for playing YEET: Let's Get That Bread Back.
You are an ordinary villager who is tasked with the holy job of returning
what is rightfully your village's. Deep in the night your bread was stolen
by many monsters hiding in the caves. You must return that bread so your
village can once again be victorious.
For starters, make sure you have pygame, libtcodpy, shelve and textwrap 
downloaded as python modules.
Open up the init file and run! Boom. Have fun.
You can move with the arrow keys or mouse.
Pick up with "g"
Drop menu with "d"
Inventory menu with "i"
Spell menu with "s"
Ranged attack with mouse.
Regular attack by moving into monsters or clicking on monsters.
Go down or up stairs with "<" and ">"
O and did I forget that you can use "o" for auto explore!
Now you are ready to embark on an epic adventure deep (well I guess only
10 levels down) into the caverns to defeat the boss Troll and get that bread back.