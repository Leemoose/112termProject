import libtcodpy as libtcod
import math, textwrap, shelve, pygame

# Basic structure of this code is based on a http://roguebasin.com/index.php?title=Main_Page tutorial.
#Noises from sound bible at http://soundbible.com


DEFAULT_SPEED = 8
DEFAULT_ATTACK_SPEED = 20
wall_tile = 256 
floor_tile = 257
player_tile = 258
orc_tile = 259
troll_tile = 260
scroll_tile = 261
healingpotion_tile = 262
sword_tile = 263
shield_tile = 264
stairsdown_tile = 265
dagger_tile = 266

LIGHTNING_DAMAGE = 20
LIGHTNING_RANGE = 5
CONFUSE_NUM_TURNS = 10
CONFUSE_RANGE = 8
FIREBALL_RADIUS = 3
FIREBALL_DAMAGE = 20

def run():
    data = initGame()
    libtcod.console_set_default_foreground(0, libtcod.light_yellow)
    libtcod.console_print_ex(0, SCREEN_WIDTH/2, SCREEN_HEIGHT/2 - 4, libtcod.BKGND_NONE,
        libtcod.CENTER, "Diablo I?")
    libtcod.console_print_ex(0, SCREEN_WIDTH/2, SCREEN_HEIGHT-2, libtcod.BKGND_NONE,
        libtcod.CENTER, "C. Leemhuis")
    main_menu(data)
    # main_menu(data)

def initVar(): #Initialize major variables
    class Struct(object): pass
    data = Struct()
    data.LIMIT_FPS = 20
    data.ROOM_MAX_SIZE = 10
    data.ROOM_MIN_SIZE = 6
    data.MAX_ROOMS = 30
    global FOV_LIGHT_WALLS, FOV_ALGO, MSG_X, BAR_WIDTH, PANEL_HEIGHT, PANEL_Y
    FOV_ALGO = 0 #Default
    FOV_LIGHT_WALLS = True
    data.MAX_ROOM_MONSTERS = 3
    data.player_action = None
    BAR_WIDTH = 20
    PANEL_HEIGHT = 7
    MSG_X = BAR_WIDTH + 2
    data.MAX_ROOMS_ITEMS = 2
    data.INVENTORY_WIDTH = 50
    initColors(data)
    defineGlobals(data)
    PANEL_Y = SCREEN_HEIGHT - PANEL_HEIGHT
    return data

def defineGlobals(data):
    global game_state, player, objects, DEFAULT_SPEED, DEFAULT_ATTACK_SPEED, PLAYER_SPEED
    global panel, MSG_WIDTH, MSG_HEIGHT, game_msgs, mouse, key, inventory, PLAYER_MAXHOLD, seenObjects
    global HEAL_AMOUNT, fov_recompute, TORCH_RADIUS, gameLevel, masterMap, masterObjects, spells, file
    defineGlobalSpells()
    defineGlobalScreen()
    spells = ["Fireball", "Lightning"]
    HEAL_AMOUNT = 6
    DEFAULT_SPEED = 8
    DEFAULT_ATTACK_SPEED = 20
    PLAYER_SPEED = 2
    game_state = "playing"
    fighter_component = Fighter(hp = 30, defense = 2, power = 5, death_function = player_death)
    player_component = Player(vitality = 10, intelligence = 6, strength = 10, dexterity = 6)
    player = Object(0, 0, player_tile, "player", libtcod.white, blocks = True, 
        fighter = fighter_component, player1 = player_component, speed = PLAYER_SPEED)
    objects = [player]
    panel = libtcod.console_new(SCREEN_WIDTH, PANEL_HEIGHT)
    MSG_WIDTH = SCREEN_WIDTH - BAR_WIDTH - 2
    MSG_HEIGHT = PANEL_HEIGHT - 1
    game_msgs = []
    mouse = libtcod.Mouse()
    key = libtcod.Key()
    PLAYER_MAXHOLD = 26
    inventory = []
    fov_recompute = True
    TORCH_RADIUS = 10
    gameLevel = 1
    masterMap = []
    masterObjects = []
    seenObjects = set()

def defineGlobalScreen():
    global SCREEN_WIDTH, SCREEN_HEIGHT, MAP_HEIGHT, MAP_WIDTH
    SCREEN_WIDTH = 80
    SCREEN_HEIGHT = 50
    MAP_WIDTH = 80
    MAP_HEIGHT = 43

def defineGlobalSpells():
    # global LIGHTNING_DAMAGE, LIGHTNING_RANGE, CONFUSE_NUM_TURNS, CONFUSE_RANGE
    # global FIREBALL_RADIUS, FIREBALL_DAMAGE
    # LIGHTNING_DAMAGE = 20
    # LIGHTNING_RANGE = 5
    # CONFUSE_NUM_TURNS = 10
    # CONFUSE_RANGE = 8
    # FIREBALL_RADIUS = 3
    # FIREBALL_DAMAGE = 12
    pass

def initColors(data):
    data.color_dark_wall = libtcod.Color(0, 0, 100)
    data.color_dark_ground = libtcod.Color(50, 50, 150)
    data.color_light_wall = libtcod.Color(130, 11, 50)
    data.color_light_ground = libtcod.Color(200, 180, 50)

def initGame():
    pygame.mixer.init()
    data = initVar()
    libtcod.console_set_custom_font('images/tiledFont.png', libtcod.FONT_TYPE_GREYSCALE | libtcod.FONT_LAYOUT_TCOD, 32, 10)
    libtcod.console_init_root(SCREEN_WIDTH, SCREEN_HEIGHT,
        "python/libtcod tutorial", False)
    load_customfont()
    global con
    con = libtcod.console_new(MAP_WIDTH, MAP_HEIGHT)
    return data

def newGame(data):
    pygame.mixer.music.load("sus.mp3")
    pygame.mixer.music.play()
    libtcod.sys_set_fps(data.LIMIT_FPS)
    make_map(data)
    make_fovMap()
    message("Welcome stranger! Prepare to be yeeted upon by my zounds of orcs!",
        libtcod.red)

def nextLevel(data):
    global objects, player, fov_recompute, masterMap, gameLevel, map1, masterObjects
    if len(masterMap) == gameLevel:
        masterObjects.append(objects)
        gameLevel += 1
        objects = [player]
        make_map(data)
        fov_recompute = True
        make_fovMap()

def prevLevel(data):
    global gameLevel, map1, objects, fov_recompute, master_fov_map, fov_map
    if gameLevel != 1:
        gameLevel -= 1
        map1 = masterMap[gameLevel - 1]
        objects = masterObjects[gameLevel - 1]
        fov_recompute = True
        for people in objects:
            if people.name == "stairs":
                player.x = people.x
                player.y = people.y
        make_fovMap()


def playGame(data):
    global key, mouse, player_action
    while not libtcod.console_is_window_closed():
        action = mainLoop(data)
        if action == "exit":
            save_game()
            break

def main_menu(data):
    img = libtcod.image_load("images/menu_background1.png")
    while not libtcod.console_is_window_closed():
        libtcod.image_blit_2x(img, 0, 0, 0)
        choice = menu(data, "", ["Play a new game", "Continue last game", "Quit"], 24)
        if choice == 0: #new game
            data = initGame()
            newGame(data)
            playGame(data)
        if choice == 1:
            try:
                load_game(data)
                playGame(data)
            except:
                msgbox(data, "\n No saved game\n", 24)
                continue
        elif choice == 2: #quit
            break


def load_customfont():
    #The index of the first custom tile in the file
    a = 256
 
    #The "y" is the row index, here we load the sixth row in the font file. Increase the "6" to load any new rows from the file
    for y in range(5,6):
        libtcod.console_map_ascii_codes_to_font(a, 32, 0, y)
        a += 32

def save_game():
    global map1, objects, player, inventory, game_msgs, game_state, file
    file = shelve.open("savegame")
    file["map"] = map1
    file["objects"] = objects
    file["player_index"] = objects.index(player)
    file["inventory"] = inventory
    file["game_msgs"] = game_msgs
    file["game_state"] = game_state
    file.close()

def load_game(data):
    global map1, objects, player, inventory, game_msgs, game_state, file, fov_recompute
    file = shelve.open("savegame")
    map1 = file["map"]
    objects = file["objects"]
    game_state = file["game_state"]
    game_msgs = file["game_msgs"]
    inventory = file["inventory"]
    player = objects[file["player_index"]]
    file.close()
    make_fovMap()
    fov_recompute = True

def msgbox(data, text, width = 50):
    menu(data, text, [], width)
                    

#############
# RUNNING GAME
############

def mainLoop(data):
    global key, mouse
    libtcod.sys_check_for_event(libtcod.EVENT_KEY_PRESS|libtcod.EVENT_MOUSE, key, mouse)
    render_all()
    libtcod.console_flush()
        #handle keys
    for people in objects:
        people.clear(con)
    player_action = handle_keys(data)
    player.player1.checkForLevelUp()
    if player_action == "exit":
        return "exit"
    elif game_state == "playing": # and player_action != "didnt-take-turn":
        for people in objects:
            if people.ai:
                if people.wait > 0:
                    people.wait -= 1
                else:
                    people.ai.take_turn()

def is_blocked(x, y):
    #Test map tile
    if map1[x][y].blocked:
        return True
    for people in objects:
        if people.blocks and people.x == x and people.y == y:
            return True
    return False

def message(new_msg, color = libtcod.white):
    new_msg_lines = textwrap.wrap(new_msg, MSG_WIDTH)
    for line in new_msg_lines: #IF full remove
        if len(game_msgs) == MSG_HEIGHT:
            del game_msgs[0]
        game_msgs.append((line, color))

###############
#    People functions
##################
def player_move_or_attack(dx, dy, data):
    global fov_recompute
    x = player.x + dx
    y = player.y + dy

    target = None
    for people in objects:
        if people.fighter and people.x == x and people.y == y:
            target = people
            break
    if target is not None:
        player.fighter.attack(target)
    else:
        player.move(dx, dy)
        fov_recompute = True

def player_death(player):
    global game_state
    message("You died!", libtcod.darker_red)
    game_state = "dead"

    player.char = "%" #Transform player into corpse
    player.color = libtcod.dark_red

def monster_death(monster):
    #Turns into non locking corpse
    message(monster.name.capitalize() + " is dead!", libtcod.purple)
    monster.char = "%"
    monster.color = libtcod.dark_red
    monster.blocks = False
    monster.fighter = None
    monster.ai = None
    monster.name = "remains of " + monster.name
    player.player1.experience += monster.deathExperience
    monster.send_to_back()

def closest_monster(max_range):
    closest_enemy = None
    closest_dist = max_range + 1

    for people in objects:
        if people.fighter and not people == player \
        and libtcod.map_is_in_fov(fov_map, people.x, people.y):
            dist = player.distance_to(people)
            if dist < closest_dist:
                closest_enemy = people
                closest_dist = dist
    return closest_enemy

def target_tile(max_range=None):
    global key, mouse
    while True:
        libtcod.console_flush()
        libtcod.sys_check_for_event(libtcod.EVENT_KEY_PRESS|libtcod.EVENT_MOUSE,key,mouse)
        render_all()

        (x,y) = (mouse.cx, mouse.cy)
        if mouse.lbutton_pressed and libtcod.map_is_in_fov(fov_map, x, y) and \
        (max_range is None or player.distance(x, y) <= max_range):
            return (x,y)
        elif mouse.rbutton_pressed or key.vk == libtcod.KEY_ESCAPE:
            return (None, None) #Cancelled

def target_monster(max_range = None):
    #Returns clicked monster
    while True:
        (x, y) = target_tile(max_range)
        if x is None:
            return None

        for people in objects:
            if people.x == x and people.y == y and people.fighter and people != player:
                return people

############
#  ITEM FUNCTIONS
#################

def cast_heal():
    if player.fighter.hp == player.fighter.max_hp:
        message("You at full health B!", libtcod.red)
        return "cancelled"
    pygame.mixer.music.load("slurp.mp3")
    pygame.mixer.music.play()

    message("Your wounds begin to close...", libtcod.light_violet)
    player.fighter.heal(HEAL_AMOUNT)

def cast_lightning():
    monster = closest_monster(LIGHTNING_RANGE)
    if monster is None: #No enemy
        message("No enemy within range.", libtcod.purple)
        return "cancelled"
    message("A bolt of lightning zaps the " + monster.name + "with damage " +\
        str(LIGHTNING_DAMAGE), libtcod.light_blue)
    monster.fighter.take_damage(LIGHTNING_DAMAGE)

def cast_confuse():
    message("Left ticket to confuse monster, right click cancel", libtcod.green)
    monster = target_monster(CONFUSE_RANGE)
    if monster is None:
        return "cancelled"
    else:
        old_ai = monster.ai
        monster.ai = ConfusedMonster(old_ai)
        #Tells new component who owns it
        monster.ai.owner = monster
        message("The monster begins to stumble around...", libtcod.light_green)

def cast_fireball():
    #asks player for tile to throw fireball
    message("Left click on tile for fireball or right click cancel.", libtcod.cyan)
    (x, y) = target_tile()
    if x is None: return "cancelled"
    message("A burning mass burns a large area in " + str(FIREBALL_RADIUS) + " tiles!",
        libtcod.orange)
    for people in objects:
        if people.distance(x, y) <= FIREBALL_RADIUS and people.fighter:
            message("The " + people.name + " takes " + str(FIREBALL_DAMAGE) + " fire damage!",
                libtcod.orange)
            people.fighter.take_damage(FIREBALL_DAMAGE)

def winTheGame():
    message("You have won the game!", libtcod.white)
    message("The bread has been liberated and the people are happy!", libtcod.white)
    img = libtcod.image_load("images/breadCelebration.jpg")
    while not libtcod.console_is_window_closed():
        libtcod.image_blit_2x(img, 0, 0, 0)
        choice = menu(data, "", ["Play a new game", "Continue", "Quit"], 24)
        if choice == 0: #new game
            data = initGame()
            newGame(data)
            playGame(data)
        if choice == 1:
            try:
                load_game(data)
            except:
                msgbox(data, "\n No saved game\n", 24)
                continue
        elif choice == 2: #quit
            break



################
#    KEYS
#################

def handle_keys(data): #Handles player movement
    global key, fov_recompute
    if player.wait > 0:
        player.wait -= 1
        return
    if key.vk == libtcod.KEY_ENTER and key.lalt:
        libtcod.console_set_fullscreen(not libtcod.console_is_fullscreen())
    elif key.vk == libtcod.KEY_ESCAPE:
        return "exit"
    if game_state == "playing": #Movement
        if (mouse.lbutton_pressed):
            x = mouse.cx
            y = mouse.cy
            player_mouse_move(x, y)


        if key.vk == libtcod.KEY_UP:
            player_move_or_attack(0,-1, data)
            fov_recompute = True
        elif key.vk == libtcod.KEY_DOWN:
            player_move_or_attack(0,1, data)
            fov_recompute = True
        elif key.vk == libtcod.KEY_LEFT:
            player_move_or_attack(-1,0, data)
            fov_recompute = True
        elif key.vk == libtcod.KEY_RIGHT:
            player_move_or_attack(1,0, data)
            fov_recompute = True
        else:
            key_char = chr(key.c)
            if key_char == "g":
                for people in objects:
                    if people.x == player.x and people.y == player.y and people.item:
                        people.item.pick_up()
                        break
            elif key_char == "i":
                chosen_item = inventory_menu(data, "Press the key next to item to use it.")
                if chosen_item is not None:
                    chosen_item.use()
            elif key_char == "m":
                chosen_spell = spell_menu(data, "Press the key next to spell to use it.")
                if chosen_spell is not None:
                    player.player1.cast_spell(chosen_spell)
            elif key_char == "d":
                chosen_item = inventory_menu(data, "Press key next to item to drop it.")
                if chosen_item is not None:
                    chosen_item.drop()
            elif key_char == "," and key.shift:
                x,y = stairsDCoor
                if x == player.x and y == player.y:
                    nextLevel(data)
            elif key_char == "." and key.shift:
                x,y = stairsUCoor
                if x == player.x and y == player.y:
                    prevLevel(data)
            elif key_char == "o":
                player.player1.takeTurn()
            return "didnt-take-turn"

def checkForNewDiscovery():
    global fov_map, objects, seenObjects
    new = False
    for people in objects:
        if people.ai != None:
            if libtcod.map_is_in_fov(fov_map, people.x, people.y):
                return True
        else:
            if people not in seenObjects:
                seenObjects.add(people)
                new = True
    return new

def player_mouse_move(x, y): 
    global fov_recompute
    target = None
    for people in objects:
        if people.fighter and people.x == x and people.y == y:
            target = people
            if target == player:
                return
            break
    if target is not None and player.distance_to(target) <= 2 ** (.5):
        player.fighter.attack(target)
    elif target is not None and player.distance_to(target) <= 5:
        player.fighter.rangedAttack(target)
    else:
        player.move_astar(x, y)
        fov_recompute = True

def get_names_under_mouse():
    global mouse
    #Return obj under mouse
    (x, y) = (mouse.cx, mouse.cy)
    #Get list of all objects under key
    names = [obj.name for obj in objects
        if obj.x == x and obj.y == y and libtcod.map_is_in_fov(fov_map, obj.x, obj.y)]
    names = ", ".join(names)
    return names.capitalize()

####################
#     SCREENS
#####################

def menu(data, header, options, width):
    global key, mouse
    if len(options) > 26: raise ValueError("Cannot > 26 options.")
    header_height = libtcod.console_get_height_rect(con, 0, 0, width, 
        SCREEN_HEIGHT, header)
    if header == "":
        header_height = 0
    height = len(options) + header_height
    window = libtcod.console_new(width, height)
    #print header with auto wrap
    libtcod.console_set_default_foreground(window, libtcod.white)
    libtcod.console_print_rect_ex(window, 0, 0, width, height, libtcod.BKGND_NONE,
        libtcod.LEFT, header)
    y = header_height
    letter_index = ord("a")
    for option_text in options:
        text = "(" + chr(letter_index) + ")" + option_text
        libtcod.console_print_ex(window, 0, y, libtcod.BKGND_NONE,
            libtcod.LEFT, text)
        y += 1
        letter_index += 1
    x = SCREEN_WIDTH/2 - width/2
    y = SCREEN_HEIGHT/2 - height/2
    libtcod.console_blit(window, 0, 0, width, height, 0, x, y, 1.0, 0.7)
    libtcod.console_flush()
    key = libtcod.console_wait_for_keypress(True)
    if key.vk == libtcod.KEY_ENTER and key.lalt:
        libtcod.console_set_fullscreen(not libtcod.console_is_fullscreen())
    index = key.c - ord("a")
    if index >= 0 and index < len(options): return index
    return None

def inventory_menu(data, header):
    #Menu with each item of inve as option
    global inventory
    if len(inventory) == 0:
        options = ["Inventory is empty."]
    else:
        options = []
        for item in inventory:
            if isinstance(item.item, Equipment):
                add = item.name
                if item.item.defense > 0:
                    add += ": Defemse +" + str(item.item.defense)
                if item.item.offense > 0:
                    add += ": Offense +" + str(item.item.offense)
                if item.item.equipped:
                    add += " is equipped."
                else:
                    add += " is unequipped."
            else:
                add = item.name
            options.append(add)
    index = menu(data, header, options, data.INVENTORY_WIDTH)
    if index is None or len(inventory) == 0: return None
    return inventory[index].item

def spell_menu(data, header):
    #Menu with each item of inve as option
    global spells
    if len(spells) == 0:
        options = ["You have no spells."]
    else:
        options = [spell for spell in spells]
    index = menu(data, header, options, data.INVENTORY_WIDTH)
    if index is None or len(spells) == 0: return None
    return spells[index]


#####################
#    MAPS + PLACEMENT
####################

def make_map(data):
    global map1, player, masterMap, gameLevel
    finish = False
    while not finish:
        map1 = [[Tile(True)
            for y in range(MAP_HEIGHT)]
                for x in range(MAP_WIDTH)]
        try:
            nodes = splitRectangle(0, 0, MAP_WIDTH, MAP_HEIGHT, data)
            finish = True
        except:
            pass


    for i in range(10):
        x = libtcod.random_get_int(0, 0, MAP_WIDTH)
        x1 = libtcod.random_get_int(0, 0, MAP_WIDTH)
        y = libtcod.random_get_int(0, 0 , MAP_HEIGHT)
        if x < x1:
            while abs(x1 - x) > 8:
                x1 -= 1
                x += 1
            try:
                create_h_tunnel(x, x1, y)
                if y < MAP_HEIGHT:
                    create_h_tunnel(x, x1, y + 1)
            except:
                pass
        else:
            while abs(x - x1) > 8:
                x1 += 1
                x -= 1
            try:
                create_h_tunnel(x1, x, y)
            except:
                pass
    for i in range(10):
        x = libtcod.random_get_int(0, 0, MAP_WIDTH)
        y1 = libtcod.random_get_int(0, 0, MAP_HEIGHT)
        y = libtcod.random_get_int(0, 0 , MAP_HEIGHT)
        if y < y1:
            while abs(y1 - y) > 8:
                y1 -= 1
                y += 1
            try:
                create_v_tunnel(y, y1, x)
                if x < MAP_WIDTH:
                    create_h_tunnel(y, y1, x + 1)
            except:
                pass
        else:
            while abs(y - y1) > 8:
                y1 += 1
                y -= 1
            try:
                create_h_tunnel(y1, y, x)
            except:
                pass
    counter = 0
    for y in range(MAP_HEIGHT):
        for x in range(MAP_WIDTH):
            if map1[x][y].blocked == True:
                counter += 1
            else:
                if counter > 10:
                    splX = int(x - counter / 2)
                    create_h_tunnel(splX - 1, splX + 1, y)
                    counter = 0
        if counter > 6:
                    splX = int(x - counter / 2)
                    create_h_tunnel(splX - 1, splX + 1, y)
        counter = 0
    for x in range(MAP_WIDTH):
        for y in range(MAP_HEIGHT):
            if map1[x][y].blocked == True:
                counter += 1
            else:
                if counter > 10:
                    splY = int(y - counter / 2)
                    create_v_tunnel(splY - 1, splY + 1, x)
                    counter = 0
        if counter > 6:
            splY = int(y - counter / 2)
            create_v_tunnel(splY - 1, splY + 1, x)
        counter = 0

    pX = libtcod.random_get_int(0, 1, MAP_WIDTH - 1)
    pY = libtcod.random_get_int(0, 1, MAP_HEIGHT - 1)
    while map1[pX][pY].blocked:
        pX = libtcod.random_get_int(0, 1, MAP_WIDTH - 1)
        pY = libtcod.random_get_int(0, 1, MAP_HEIGHT - 1)
    player.x = pX
    player.y = pY
    global stairsUCoor
    stairsUCoor = (pX, pY)
    stairsUp = Object(pX, pY, '>', 'stairsUp', libtcod.white, always_seen = True)
    objects.append(stairsUp)
    stairsUp.send_to_back()
    sX = libtcod.random_get_int(0, 0, MAP_WIDTH)
    sY = libtcod.random_get_int(0, 0, MAP_HEIGHT)
    if gameLevel != 10:
        sX = libtcod.random_get_int(0, 1, MAP_WIDTH-1)
        sY = libtcod.random_get_int(0, 1, MAP_HEIGHT-1)
        while map1[pX][pY].blocked:
            sX = libtcod.random_get_int(0, 1, MAP_WIDTH-1)
            sY = libtcod.random_get_int(0, 1, MAP_HEIGHT-1)
        global stairsDCoor
        stairsDCoor = (sX, sY)
        stairsD = Object(sX, sY, '<', 'stairs', libtcod.white, always_seen = True)
        objects.append(stairsD)
        stairsD.send_to_back()
    else:
        bRoom = [0, 0, 0, 0]
        for i in range(len(nodes) // 4):
            a = nodes[i * 4]
            b = nodes[i * 4 + 1]
            c = nodes[i * 4 + 2]
            d = nodes[i * 4 + 3]
            if (c - a - 2)*(d - b - 2) > (bRoom[2] - bRoom[0] - 2)*(bRoom[3] - bRoom[1] - 2):
                bRoom[0] = a
                bRoom[1] = b
                bRoom[2] = c
                bRoom[3] = d
        placeBreadAndBOSS(bRoom)
    masterMap.append(map1)




def splitRectangle(x1, y1, x2, y2, data):
    if abs(x2 - x1) < libtcod.random_get_int(0, 5, 25) and abs(y2 - y1) < libtcod.random_get_int(0, 5, 25):
        new_room = Rect(x1, y1, x2, y2)
        create_room(new_room)
        place_objects(new_room, data) #Add stuff to room
        box = [x1, y1, x2, y2]
        return box
    nodes = []
    evenSplit = libtcod.random_get_float(0, 0, 1)
    if abs(x2 - x1) + 5 < abs(y2 - y1):
        evenSplit = .3
    elif abs(y2 - y1) + 5 < abs(x2 - x1):
        evenSplit = .8
    unevenSplit = libtcod.random_get_float(0, .45, .55)
    if evenSplit > .5:
        newX = int((x2 - x1) * unevenSplit + x1)
        nodes += splitRectangle(x1, y1, newX, y2, data)
        ySplit = libtcod.random_get_int(0, y1 + 1, y2 - 1)
        create_h_tunnel(newX, newX + 1, ySplit)
        if ySplit > y1:
            create_h_tunnel(newX, newX + 1, ySplit - 1)
        else:
            create_h_tunnel(newX, newX + 1, ySplit + 1)
        nodes += splitRectangle(newX + 1, y1, x2, y2, data)
        return nodes
    else:
        newY = int((y2 - y1) * unevenSplit + y1)
        nodes += splitRectangle(x1, y1, x2, newY, data)
        xSplit = libtcod.random_get_int(0, x1 + 1, x2 - 1)
        create_v_tunnel(newY, newY + 1, xSplit)
        if xSplit > x1:
            create_v_tunnel(newY, newY + 1, xSplit - 1)
        else:
            create_v_tunnel(newY, newY + 1, xSplit + 1)
        nodes += splitRectangle(x1, newY + 1, x2, y2, data)
        return nodes

def circle_point(r):
    angle = libtcod.random_get_float(0, 0, 2 * math.pi)
    x = r * math.cos(angle) * libtcod.random_get_float(0, 0, 1)
    y = r * math.sin(angle) * libtcod.random_get_float(0, 0, 1)
    return (int(x + r), int(y + r))

def make_fovMap():
    global fov_map, MAP_WIDTH, MAP_HEIGHT, map1
    libtcod.console_clear(con)
    fov_map = libtcod.map_new(MAP_WIDTH, MAP_HEIGHT)
    for y in range(MAP_HEIGHT):
        for x in range(MAP_WIDTH):
            libtcod.map_set_properties(fov_map, x, y,
                not map1[x][y].block_sight, not map1[x][y].blocked)

def create_room(room):
    global map1
    #makes passable room
    for x in range(room.x1 + 1 , room.x2):
        for y in range(room.y1 + 1, room.y2):
            if x > 0 and y > 0 and x < MAP_WIDTH - 1 and y < MAP_HEIGHT - 1:
                map1[x][y].blocked = False
                map1[x][y].block_sight = False

def create_h_tunnel(x1, x2, y): #Makes passable tunnel
    global map1
    for x in range(min(x1, x2), max(x1, x2) + 1):
        if x > 0 and y > 0 and x < MAP_WIDTH - 1 and y < MAP_HEIGHT - 1:
            map1[x][y].blocked = False
            map1[x][y].block_sight = False

def create_v_tunnel(y1, y2, x): #Vert tunnel
    global map1
    for y in range(min(y1, y2), max(y1, y2) + 1):
        if x > 0 and y > 0 and x < MAP_WIDTH - 1 and y < MAP_HEIGHT - 1:
            map1[x][y].blocked = False
            map1[x][y].block_sight = False

def placeBreadAndBOSS(room): #BOSS ENDING
    global gameLevel
    x = libtcod.random_get_int(0, room[0] + 1, room[2] - 1)
    y = libtcod.random_get_int(0, room[1] + 1, room[3] - 1)
    item_component = Item(use_function = winTheGame)
    bread = Object(x,y, "$", "THE BREAD", libtcod.dark_green, item = item_component)
    x = libtcod.random_get_int(0, room[0] + 1, room[2] - 1)
    y = libtcod.random_get_int(0, room[1] + 1, room[3] - 1)
    while is_blocked(x,y):
        x = libtcod.random_get_int(0, room[0] + 1, room[2] - 1)
        y = libtcod.random_get_int(0, room[1] + 1, room[3] - 1)
    fighter_component = Fighter(hp = 150, defense = 30, power = 35, death_function = monster_death)
    ai_component = BasicMonster()
    monster = Object(x, y, troll_tile, "MEGA TROLL", libtcod.dark_red, fighter = fighter_component,
                    ai = ai_component, deathExperience = 10000)

    num_monsters = 10

    for i in range(num_monsters):#place monsters
        x = libtcod.random_get_int(0, room[0] + 1, room[2] - 1)
        y = libtcod.random_get_int(0, room[1] + 1, room[3] - 1)
        if not is_blocked(x, y):
            if libtcod.random_get_int(0, 0, 100) < 80: #Create orc
                fighter_component = Fighter(hp = (20 + 3 * gameLevel), defense = (2 + gameLevel), power = (3 +gameLevel), death_function =monster_death)
                ai_component = BasicMonster()
                monster = Object(x, y, orc_tile, "orc", libtcod.white, blocks = True,
                    fighter = fighter_component, ai = ai_component, deathExperience = 10)

            else: #Create troll
                fighter_component = Fighter(hp = 30 + 5 * gameLevel, defense = 3 + 3 * gameLevel // 2, power = 6 + 3 * gameLevel // 2, death_function = monster_death)
                ai_component = BasicMonster()
                monster = Object(x, y, troll_tile, "troll", libtcod.white, fighter = fighter_component,
                    ai = ai_component, deathExperience = 25)

            objects.append(monster)


        # MONSTERS
def place_objects(room, data):
    global gameLevel
    num_monsters = libtcod.random_get_int(0, 0, data.MAX_ROOM_MONSTERS + gameLevel - 2)

    for i in range(num_monsters):#place monsters
        x = libtcod.random_get_int(0, room.x1 + 1, room.x2 - 1)
        y = libtcod.random_get_int(0, room.y1 + 1, room.y2 - 1)
        if not is_blocked(x, y):
            dice = libtcod.random_get_int(0, 0, 100)
            if dice < 75: #Create orc
                fighter_component = Fighter(hp = (17 + 3 * gameLevel), defense = (2 + gameLevel), power = (3 +gameLevel), death_function =monster_death)
                ai_component = BasicMonster(ranged = False)
                monster = Object(x, y, orc_tile, "orc", libtcod.white, blocks = True,
                    fighter = fighter_component, ai = ai_component, deathExperience = 10 + 5 * gameLevel)

            elif 75 <= dice < 90: #Create troll
                fighter_component = Fighter(hp = 25 + 5 * gameLevel, defense = 3 + 3 * gameLevel // 2, power = 3 + 2 * gameLevel, death_function = monster_death)
                ai_component = BasicMonster(ranged = False)
                monster = Object(x, y, troll_tile, "troll", libtcod.white, fighter = fighter_component, blocks = True,
                    ai = ai_component, deathExperience = 25 + 15 * gameLevel)
            elif 90 <= dice:
                fighter_component = Fighter(hp = (20 + 3 * gameLevel), defense = (2 + gameLevel), power = (4 +gameLevel * 3 // 2), death_function =monster_death)
                ai_component = BasicMonster(ranged = True)
                monster = Object(x, y, orc_tile, "ranged orc", libtcod.white, blocks = True,
                    fighter = fighter_component, ai = ai_component, deathExperience = 15 + 10 * gameLevel)
            objects.append(monster)

    num_items = libtcod.random_get_int(0, 0, data.MAX_ROOMS_ITEMS)

    for i in range(num_items):
        x = libtcod.random_get_int(0, room.x1 + 1, room.x2 - 1)
        y = libtcod.random_get_int(0, room.y1 + 1, room.y2 - 1)

        if not is_blocked(x, y):
            dice = libtcod.random_get_int(0, 0, 100)
            if dice< 50:
                #create healing potion
                item_component = Item(use_function = cast_heal)
                item = Object(x, y, healingpotion_tile, "healing potion", libtcod.white, item = item_component)
            elif dice < 50 + 10:
                item_component = Item(use_function = cast_lightning)
                item = Object(x, y, "#", "scroll of lightning bolt", 
                    libtcod.light_yellow, item = item_component)
            elif dice < 50 + 10 + 10:
                #Confuse scroll
                item_component = Item(use_function = cast_confuse)
                item = Object(x, y, "#", "scroll of confusion", libtcod.light_yellow, item = item_component)
            elif dice < 50 + 10 + 10 + 10:#Fireball scroll
                item_component = Item(use_function = cast_fireball)
                item = Object(x, y, "#", "scroll of fireball", libtcod.light_yellow, item = item_component)
            elif dice < 50 + 10 + 10+ 10 + 10:
                weapon_component = Equipment(offense = 3, hands = 1)
                item = Object(x, y, sword_tile, "Sword", libtcod.white, item = weapon_component)
            else:
                shield_component = Equipment(defense = 1, hands = 1)
                item = Object(x, y, shield_tile, "Shield", libtcod.white, item = shield_component)


            objects.append(item)
            item.send_to_back()

#############
# DRAW
############

def render_all():
    global fov_recompute, player, objects, seenObjects

    if fov_recompute: #Recomute FOV
        fov_recompute = False
        libtcod.map_compute_fov(fov_map, player.x, player.y,
            TORCH_RADIUS, FOV_LIGHT_WALLS, FOV_ALGO)
        for people in objects:
            if libtcod.map_is_in_fov(fov_map, people.x, people.y):
                seenObjects.add(people)

    for y in range(MAP_HEIGHT):
        for x in range(MAP_WIDTH):
            visible = libtcod.map_is_in_fov(fov_map, x, y)
            wall = map1[x][y].block_sight
            # visible = True
            if not visible:
                if map1[x][y].explored:
                    if wall:
                        libtcod.console_put_char_ex(con, x, y, wall_tile, libtcod.grey, libtcod.black)
                    else:
                        libtcod.console_put_char_ex(con, x, y, floor_tile, libtcod.grey, libtcod.black)
            else:
                #it's visible
                if wall:
                    libtcod.console_put_char_ex(con, x, y, wall_tile, libtcod.white, libtcod.black)
                else:
                    libtcod.console_put_char_ex(con, x, y, floor_tile, libtcod.white, libtcod.black)
                        #since it's visible, explore it

    for people in objects:
        if people != player:
            people.draw(con)
    player.draw(con)
    #pt cons to root console
    libtcod.console_blit(con, 0, 0, SCREEN_WIDTH, SCREEN_HEIGHT,
            0, 0, 0)

    libtcod.console_set_default_background(panel, libtcod.black)
    libtcod.console_clear(panel)
    #Show player stats
    y = 1
    for (line, color) in game_msgs:
        libtcod.console_set_default_foreground(panel, color)
        libtcod.console_print_ex(panel, MSG_X, y, libtcod.BKGND_NONE,
            libtcod.LEFT, line)
        y += 1
    #Health
    render_bar(1, 1, BAR_WIDTH, "HP", player.fighter.hp, player.fighter.max_hp,
        libtcod.light_red, libtcod.darker_red)

    render_bar(1, 2, BAR_WIDTH, "Mana", player.player1.mana, player.player1.maxMana, libtcod.light_blue,
        libtcod.darker_blue)

    render_bar(1, 3, BAR_WIDTH, "XP", player.player1.experience, player.player1.level * 30,
        libtcod.light_gray, libtcod.darker_gray)

    libtcod.console_print_ex(panel, 5, 4, libtcod.BKGND_NONE,
        libtcod.CENTER, "Power: " + str(player.fighter.power))
    libtcod.console_print_ex(panel, 6, 5, libtcod.BKGND_NONE,
        libtcod.CENTER, "Defense: " + str(player.fighter.defense))


    libtcod.console_set_default_foreground(con, libtcod.light_gray)
    #Objects under mouse

    libtcod.console_print_ex(panel, 1, 0, libtcod.BKGND_NONE, libtcod.LEFT, get_names_under_mouse())
    libtcod.console_blit(panel, 0, 0, SCREEN_WIDTH, PANEL_HEIGHT, 0, 
        0, PANEL_Y)
    

def render_bar(x, y, total_width, name, value, maximum, bar_color, back_color):
    #Render bar, need width
    bar_width = int(float(value) / maximum * total_width)
    #Render background
    libtcod.console_set_default_background(panel, back_color)
    libtcod.console_rect(panel, x, y, total_width, 1, False, libtcod.BKGND_SCREEN)
    #Render bar
    libtcod.console_set_default_background(panel, bar_color)
    if bar_width > 0:
        libtcod.console_rect(panel, x, y, bar_width, 1, False, libtcod.BKGND_SCREEN)
    libtcod.console_set_default_foreground(panel, libtcod.white)
    libtcod.console_print_ex(panel, x + total_width / 2, y, libtcod.BKGND_NONE,
        libtcod.CENTER, name + ": " + str(value) + "/" + str(maximum))



#######################
#     OBJECTS
######################

class Object:
    #Super generic
    def __init__(self, x, y, char, name, color, blocks = False, fighter = None, 
        ai = None, speed = DEFAULT_SPEED, item = None, always_seen = False, player1 = None, deathExperience = 0):
        self.x = x
        self.y = y
        self.char = char
        self.color = color
        self.name = name
        self.speed = speed
        self.wait = 0
        self.blocks = blocks
        self.always_seen = always_seen
        self.deathExperience = deathExperience

        self.fighter = fighter
        if self.fighter:
            self.fighter.owner = self

        self.ai = ai
        if self.ai:
            self.ai.owner = self

        self.item = item
        if self.item:
            self.item.owner = self

        self.player1 = player1
        if self.player1:
            self.player1.owner = self
            self.fighter.max_hp = 3 * self.player1.vitality
            self.fighter.power = self.player1.strength
            self.fighter.defense = self.player1.dexterity // 2

    # def __eq__(self, other):
    #     return self.x == other.x and self.y == other.y and self.name == other.name

    def send_to_back(self): #will be drawn first
        global objects
        objects.remove(self)
        objects.insert(0, self)

    def move(self, dx, dy):
        global objects
        if not is_blocked(self.x + dx, self.y + dy):
            for people in objects:
                if people.x == self.x + dx and people.y == self.y + dy and people.blocks:
                    return
            self.x += dx
            self.y += dy
            self.wait = self.speed

    def draw(self, con):
        global map1
        if (libtcod.map_is_in_fov(fov_map, self.x, self.y)) or (self.always_seen): #Add map.explored
            libtcod.console_set_default_foreground(con, self.color)
            libtcod.console_put_char(con, self.x, self.y, self.char, libtcod.BKGND_NONE)
            map1[self.x][self.y].explored = True


    def clear(self, con):
        libtcod.console_put_char(con, self.x, self.y, " ", libtcod.BKGND_NONE)

    def distance_to(self, other):
        dx = other.x - self.x
        dy = other.y - self.y
        return math.sqrt(dx ** 2 + dy ** 2)

    def move_towards(self, target_x, target_y): #vectors to target
        dx = target_x - self.x
        dy = target_y - self.y
        distance = math.sqrt(dx ** 2 + dy ** 2)

        dx = int(round(dx / distance))
        dy = int(round(dy / distance))
        self.move(dx, dy)

    def move_astar(self, x, y):
        global MAP_HEIGHT, MAP_WIDTH, map1
        fov_old = libtcod.map_new(MAP_WIDTH, MAP_HEIGHT)
        for people in objects:
            if people.blocks and people.x != x and people.y != y and people != self:
                libtcod.map_set_properties(fov_old, people.x, people.y, True, False)
        for ynot in range(MAP_HEIGHT):
            for xnot in range(MAP_WIDTH):
                libtcod.map_set_properties(fov_old, xnot, ynot, not map1[xnot][ynot].block_sight, not map1[xnot][ynot].blocked)
        path = libtcod.path_new_using_map(fov_old, 1.2)
        libtcod.path_compute(path, self.x, self.y, x, y)

        if not libtcod.path_is_empty(path):
            xMove, yMove = libtcod.path_walk(path, True)
            if x or y:
                for people in objects:
                    if people.x == xMove and people.y == yMove and people.blocks:
                        return
                self.x = xMove
                self.y = yMove
        else:
            self.move_towards(x, y)
        libtcod.path_delete(path)
        self.wait = self.speed

    def distance(self, x, y):
        return math.sqrt((x - self.x) ** 2 + (y - self.y) ** 2)

class Tile:
    def __init__(self, blocked, block_sight = None):
        self.blocked = blocked
        self.explored = False
        if block_sight is None: block_sight = blocked
        self.block_sight = block_sight

class Rect:
    #Rectangle on map to make room
    def __init__(self, x, y, x1, y1):
        if x > x1:
            self.x1 = x1
            self.x2 = x
        else:
            self.x1 = x
            self.x2 = x1
        if y > y1:
            self.y1 = y1
            self.y2 = y
        else:
            self.y2 = y1
            self.y1 = y

    def __repr__(self):
        return str((self.x1, self.x2, self.y1, self.y2))

    def center(self):
        center_x = (self.x1 + self.x2) / 2
        center_y = (self.y1 + self.y2) / 2
        return (center_x, center_y)

    def intersect(self, other): #If intersect, return T
        return (self.x1 <= other.x2 and self.x2 >= other.x1 and \
            self.y1 <= other.y2 and self.y2 >= other.y1)

    def xDist(self, other):
        xChange1 = other.x2 - self.x1
        xChange2 = other.x1 - self.x2
        # if abs(xChange2) > abs(xChange1):
        #     if xChange1 > 0:
        #         return xChange1 + 1
        #     else:
        #         return xChange - 1
        # else:
        #     if 
        #     return xChange2

    def yDist(self, other):
        yChange1 = other.y2 - self.y1
        yChange2 = other.y1 - self.y2
        if abs(yChange2) > abs(yChange1):
            return yChange1
        else:
            return yChange2


class Fighter: #All combat related props
    def __init__(self, hp, defense, power, death_function = None,
        attack_speed = DEFAULT_ATTACK_SPEED):
        self.attack_speed = attack_speed
        self.max_hp = hp
        self.death_function = death_function
        self.hp = hp
        self.defense = defense
        self.power = power

    def take_damage(self, damage): #apply damage
        if damage > 0:
            self.hp -= damage
        if self.hp <= 0:
            pygame.mixer.music.load("dead.mp3")
            pygame.mixer.music.play()
            function = self.death_function
            if function is not None:
                function(self.owner)

    def attack(self, target): #Finds attack damage
        defense = libtcod.random_get_int(0, target.fighter.defense - target.fighter.defense // 2, target.fighter.defense + target.fighter.defense // 2)
        damage = self.power - defense

        if damage > 0: #Take damage
            if self.owner.name == "player":
                message ("The player yeeted for " + str(damage) + " hit points.", libtcod.dark_red)
            else:
                message (self.owner.name.capitalize() + " attacks" +\
                " for " + str(damage) + " hit points.", libtcod.dark_pink)
            target.fighter.take_damage(damage)
            pygame.mixer.music.load("sword.mp3")
            pygame.mixer.music.play()
        else:
            message(self.owner.name.capitalize() + " attacks " + target.name + \
            " but it has no effect!")
            pygame.mixer.music.load("collide.mp3")
            pygame.mixer.music.play()
        self.owner.wait = self.attack_speed

    def rangedAttack(self, target):
        defense = libtcod.random_get_int(0, target.fighter.defense - target.fighter.defense // 2, target.fighter.defense)
        damage = self.power * 2 // 3 - defense

        if damage > 0:
            if self.owner.name == "player":
                message ("The player ranged yeeted for " + str(damage) + " hit points.", libtcod.dark_red)
            else:
                message (self.owner.name.capitalize() + " ranged attacked" +\
                " for " + str(damage) + " hit points.", libtcod.dark_pink)
            target.fighter.take_damage(damage)
            pygame.mixer.music.load("bow.mp3")
            pygame.mixer.music.play()
        else:
            message(self.owner.name.capitalize() + " ranged attacks " + target.name + \
            " but it has no effect!")
        self.owner.wait = self.attack_speed


    def heal(self, amount):
        self.hp += amount
        if self.hp > self.max_hp:
            self.hp = self.max_hp

class BasicMonster:
    def __init__(self, ranged = False):
        self.ranged = ranged

    def take_turn(self): #You see it, it sees you
        monster = self.owner
        if libtcod.map_is_in_fov(fov_map, monster.x, monster.y):
            #Move towards player
            if self.ranged == True:
                if monster.distance_to(player) >= 5:
                    monster.move_astar(player.x, player.y)
                elif player.fighter.hp > 0:
                    monster.fighter.rangedAttack(player)
            else:
                if monster.distance_to(player) >= 2:
                    monster.move_astar(player.x, player.y)
                elif player.fighter.hp > 0:
                    monster.fighter.attack(player)


class ConfusedMonster:
    def __init__(self, old_ai, num_turns = CONFUSE_NUM_TURNS):
        self.old_ai = old_ai
        self.num_turns = num_turns
        
    def take_turn(self):
        if self.num_turns > 0:
            self.owner.move(libtcod.random_get_int(0, -1, 1), 
                libtcod.random_get_int(0, -1, 1))
            self.num_turns -= 1
        else:
            self.owner.ai = self.old_ai
            message("The " + self.owner.name + " loses its confusion!", libtcod.white)

class Item:
    def __init__(self, use_function = None):
        self.use_function = use_function
    #Item that can be picked up
    def pick_up(self):
        #Add to inv, remove from map
        if len(inventory) >= PLAYER_MAXHOLD:
            message("Your inventory is full! Haha says the " +\
             self.owner.name + ".", libtcod.red)
        else:
            inventory.append(self.owner)
            objects.remove(self.owner)
            message("You picked up a " + self.owner.name + "!", libtcod.green)

    def use(self):
        #If use function, use
        if self.use_function is None:
            message("The " + self.owner.name + " cannot be used.")
        else:
            if self.use_function() != "cancelled":
                inventory.remove(self.owner) #destroyed after use

    def drop(self):
        #add to map. remove from inventory
        objects.append(self.owner)
        inventory.remove(self.owner)
        self.owner.x = player.x
        self.owner.y = player.y
        message("You dropped a " + self.owner.name, libtcod.yellow)

class Equipment:
    def __init__(self, defense = 0, offense = 0, hands = 0):
        self.defense = defense
        self.offense = offense
        self.hands = hands
        self.equipped = False

    def pick_up(self):
        #Add to inv, remove from map
        if len(inventory) >= PLAYER_MAXHOLD:
            message("Your inventory is full! Haha says the " +\
             self.owner.name + ".", libtcod.red)
        else:
            inventory.append(self.owner)
            objects.remove(self.owner)
            message("You picked up a " + self.owner.name + "!", libtcod.green)
            pygame.mixer.music.load("pickup.mp3")
            pygame.mixer.music.play()

    def use(self):
        global player
        if self.equipped:
            self.equip(mult = -1)
            player.player1.arms += self.hands
            self.equipped = not self.equipped
            message("You have unequipped your item", libtcod.light_gray)
        elif player.player1.arms - self.hands >= 0:
            self.equip()
            player.player1.arms -= self.hands
            self.equipped = not self.equipped
            message("You have equipped your item", libtcod.light_gray)

    def equip(self, mult = 1):
        global player
        player.fighter.power += self.offense * mult
        player.fighter.defense += self.defense * mult

    def drop(self):
        if not self.equipped:
            objects.append(self.owner)
            inventory.remove(self.owner)
            self.owner.x = player.x
            self.owner.y = player.y
            message("You dropped a " + self.owner.name, libtcod.yellow)

class Player:
    def __init__(self, vitality, intelligence, strength, dexterity):
        self.vitality = vitality
        self.intelligence = intelligence
        self.maxMana = intelligence
        self.mana = self.maxMana
        self.strength = strength
        self.dexterity = dexterity
        self.experience = 0
        self.level = 1
        self.arms = 2

    # def levelUp(self):
    #     self.vitality += 1
    #     self.intelligence += 1
    #     self.strength += 1
    #     self.dexterity += 1
    #     self.level += 1
    #     message(str(self.level))

    def checkForLevelUp(self):
        if self.experience >= self.level * 30:
            self.owner.fighter.power -= self.strength
            self.owner.fighter.defense -= self.dexterity // 2
            self.vitality += 1
            self.intelligence += 1
            self.strength += 1
            self.dexterity += 1
            self.level += 1
            self.owner.fighter.max_hp = 3 * self.vitality
            self.owner.fighter.hp += 3
            self.maxMana = self.intelligence
            self.mana += 1
            self.owner.fighter.power += self.strength
            self.owner.fighter.defense += self.dexterity // 2
            self.experience = self.experience // 3
            message("Level up!")

    def cast_spell(self, spell):
        if self.mana >= 5:
            if spell == "Fireball":
                cast_fireball()
                self.mana -= 5
            elif spell == "Lightning":
                cast_lightning
                self.mana -= 5

    def takeTurn(self):
        global MAP_WIDTH, player, fov_recompute, map1
        x = 1
        y = 1
        new = checkForNewDiscovery()
        while not new:
            while map1[x][y].explored or is_blocked(x,y):
                x += 1
                if x >= MAP_WIDTH -1:
                    x = 1
                    y += 1
                    if y >= MAP_HEIGHT -1:
                        return
            player_mouse_move(x, y)
            libtcod.map_compute_fov(fov_map, player.x, player.y,
            TORCH_RADIUS, FOV_LIGHT_WALLS, FOV_ALGO)
            new = checkForNewDiscovery()
run()
