from globalVariables import *
#######################
#     OBJECTS
######################

class Object:
    #Super generic
    def __init__(self, x, y, char, name, color, blocks = False, fighter = None, 
        ai = None, speed = DEFAULT_SPEED, item = None):
        self.x = x
        self.y = y
        self.char = char
        self.color = color
        self.name = name
        self.speed = speed
        self.wait = 0
        self.blocks = blocks

        self.fighter = fighter
        if self.fighter:
            self.fighter.owner = self

        self.ai = ai
        if self.ai:
            self.ai.owner = self

        self.item = item
        if self.item:
            self.item.owner = self

    def send_to_back(self): #will be drawn first
        global objects
        objects.remove(self)
        objects.insert(0, self)

    def move(self, dx, dy):
        if not is_blocked(self.x + dx, self.y + dy):
            self.x += dx
            self.y += dy
            self.wait = self.speed

    def draw(self, con):
        if libtcod.map_is_in_fov(fov_map, self.x, self.y):
            libtcod.console_set_default_foreground(con, self.color)
            libtcod.console_put_char(con, self.x, self.y, self.char, libtcod.BKGND_NONE)

    def clear(self, con):
        libtcod.console_put_char(con, self.x, self.y, " ", libtcod.BKGND_NONE)

    def distance_to(self, other):
        dx = other.x - self.x
        dy = other.y - self.y
        return math.sqrt(dx ** 2 + dy ** 2)

    def move_towards(self, target_x, target_y): #vectors to target
        dx = target_x - self.x
        dy = target_y - self.y
        distance = math.sqrt(dx ** 2 + dy ** 2)

        dx = int(round(dx / distance))
        dy = int(round(dy / distance))
        self.move(dx, dy)

    def distance(self, x, y):
        return math.sqrt((x - self.x) ** 2 + (y - self.y) ** 2)

class Tile:
    def __init__(self, blocked, block_sight = None):
        self.blocked = blocked
        self.explored = False
        if block_sight is None: block_sight = blocked
        self.block_sight = block_sight

class Rect:
    #Rectangle on map to make room
    def __init__(self, x, y, w, h):
        self.x1 = x
        self.y1 = y
        self.x2 = x + w
        self.y2 = y + h

    def center(self):
        center_x = (self.x1 + self.x2) / 2
        center_y = (self.y1 + self.y2) / 2
        return (center_x, center_y)

    def intersect(self, other): #If intersect, return T
        return (self.x1 <= other.x2 and self.x2 >= other.x1 and \
            self.y1 <= other.y2 and self.y2 >= other.y1)

class Fighter: #All combat related props
    def __init__(self, hp, defense, power, death_function = None,
        attack_speed = DEFAULT_ATTACK_SPEED):
        self.attack_speed = attack_speed
        self.max_hp = hp
        self.death_function = death_function
        self.hp = hp
        self.defense = defense
        self.power = power

    def take_damage(self, damage): #apply damage
        if damage > 0:
            self.hp -= damage
        if self.hp <= 0:
            function = self.death_function
            if function is not None:
                function(self.owner)

    def attack(self, target): #Finds attack damage
        damage = self.power - target.fighter.defense

        if damage > 0: #Take damage
            if self.owner.name == "player":
                message ("The player yeeted for " + str(damage) + " hit points.", libtcod.dark_red)
            else:
                message (self.owner.name.capitalize() + " attacks" +\
                " for " + str(damage) + " hit points.", libtcod.dark_pink)
            target.fighter.take_damage(damage)
        else:
            message(self.owner.name.capitalize() + " attacks " + target.name + \
            " but it has no effect!")
        self.owner.wait = self.attack_speed

    def heal(self, amount):
        self.hp += amount
        if self.hp > self.max_hp:
            self.hp = self.max_hp

class BasicMonster:
    def take_turn(self): #You see it, it sees you
        monster = self.owner
        if libtcod.map_is_in_fov(fov_map, monster.x, monster.y):
            #Move towards player
            if monster.distance_to(player) >= 2:
                monster.move_towards(player.x, player.y)
            elif player.fighter.hp > 0:
                monster.fighter.attack(player)

class ConfusedMonster:
    def __init__(self, old_ai, num_turns = CONFUSE_NUM_TURNS):
        self.old_ai = old_ai
        self.num_turns = num_turns
        
    def take_turn(self):
        if self.num_turns > 0:
            self.owner.move(libtcod.random_get_int(0, -1, 1), 
                libtcod.random_get_int(0, -1, 1))
            self.num_turns -= 1
        else:
            self.owner.ai = self.old_ai
            message("The " + self.owner.name + " loses its confusion!", libtcod.white)

class Item:
    def __init__(self, use_function = None):
        self.use_function = use_function
    #Item that can be picked up
    def pick_up(self):
        #Add to inv, remove from map
        if len(inventory) >= PLAYER_MAXHOLD:
            message("Your inventory is full! Haha says the " +\
             self.owner.name + ".", libtcod.red)
        else:
            inventory.append(self.owner)
            objects.remove(self.owner)
            message("You picked up a " + self.owner.name + "!", libtcod.green)

    def use(self):
        #If use function, use
        if self.use_function is None:
            message("The " + self.owner.name + " cannot be used.")
        else:
            if self.use_function() != "cancelled":
                inventory.remove(self.owner) #destroyed after use

    def drop(self):
        #add to map. remove from inventory
        objects.append(self.owner)
        inventory.remove(self.owner)
        self.owner.x = player.x
        self.owner.y = player.y
        message("You dropped a " + self.owner.name, libtcod.yellow)