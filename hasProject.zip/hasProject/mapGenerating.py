#####################
#    MAPS + PLACEMENT
####################
        # MAPS
def make_map(data): #Makes global map 
    global map1, player
    map1 = [[Tile(True)
        for y in range(MAP_HEIGHT)]
            for x in range(MAP_WIDTH)]

    rooms = []

    for i in range(10):
        point1 = circle_point(8)
        point2 = circle_point(8)
        new_room = Rect(point1[0], point1[1], point2[0], point2[1])
        rooms.append(new_room)

    failed = True
    while failed:
        for i in (1, range(rooms)):
            for j in (i - 1):
                if rooms[i].intersect(rooms[j]):
                    moveX = xDist(rooms[i], rooms[j])
                    moveY = yDist(rooms[i], rooms[j])
                    rooms[i].x1 += moveX
                    rooms[i].x2 += moveX
                    rooms[i].y1 += moveY
                    rooms[i].y2 += moveY
        failed = False
        for room in rooms:
            for otherRoom in rooms:
                if room.intersect(otherRoom):
                    failed = True


    

def circle_point(r):
    angle = libtcod.random_get_int(0, 0, 2 * math.pi)
    x = r * math.cos(angle)
    y = r * math.sin(angle)
    return (x + r, y + r)

def make_fovMap(data):
    global fov_map
    libtcod.console_clear(con)
    fov_map = libtcod.map_new(MAP_WIDTH, MAP_HEIGHT)
    for y in range(MAP_HEIGHT):
        for x in range(MAP_WIDTH):
            libtcod.map_set_properties(fov_map, x, y,
                not map1[x][y].block_sight, not map1[x][y].blocked)

def create_room(room):
    global map1
    #makes passable room
    for x in range(room.x1 + 1 , room.x2):
        for y in range(room.y1 + 1, room.y2):
            map1[x][y].blocked = False
            map1[x][y].block_sight = False

def create_h_tunnel(x1, x2, y): #Makes passable tunnel
    global map1
    for x in range(min(x1, x2), max(x1, x2) + 1):
        map1[x][y].blocked = False
        map1[x][y].block_sight = False

def create_v_tunnel(y1, y2, x): #Vert tunnel
    global map1
    for y in range(min(y1, y2), max(y1, y2) + 1):
        map1[x][y].blocked = False
        map1[x][y].block_sight = False

        # MONSTERS
def place_objects(room, data):
    num_monsters = libtcod.random_get_int(0, 0, data.MAX_ROOM_MONSTERS)

    for i in range(num_monsters):#place monsters
        x = libtcod.random_get_int(0, room.x1 + 1, room.x2 - 1)
        y = libtcod.random_get_int(0, room.y1 + 1, room.y2 - 1)
        if not is_blocked(x, y):
            if libtcod.random_get_int(0, 0, 100) < 80: #Create orc
                fighter_component = Fighter(hp = 10, defense = 0, power = 3, death_function =monster_death)
                ai_component = BasicMonster()
                monster = Object(x, y, orc_tile, "orc", libtcod.white, blocks = True,
                    fighter = fighter_component, ai = ai_component)

            else: #Create troll
                fighter_component = Fighter(hp = 16, defense = 1, power = 4, death_function = monster_death)
                ai_component = BasicMonster()
                monster = Object(x, y, troll_tile, "troll", libtcod.white, fighter = fighter_component,
                    ai = ai_component)

            objects.append(monster)

    num_items = libtcod.random_get_int(0, 0, data.MAX_ROOMS_ITEMS)

    for i in range(num_items):
        x = libtcod.random_get_int(0, room.x1 + 1, room.x2 - 1)
        y = libtcod.random_get_int(0, room.y1 + 1, room.y2 - 1)

        if not is_blocked(x, y):
            dice = libtcod.random_get_int(0, 0, 100)
            if dice< 70:
                #create healing potion
                item_component = Item(use_function = cast_heal)
                item = Object(x, y, healingpotion_tile, "healing potion", libtcod.white, item = item_component)
            elif dice < 70 + 10:
                item_component = Item(use_function = cast_lightning)
                item = Object(x, y, "#", "scroll of lightning bolt", 
                    libtcod.light_yellow, item = item_component)
            elif dice < 70 + 10 + 10:
                #Confuse scroll
                item_component = Item(use_function = cast_confuse)
                item = Object(x, y, "#", "scroll of confusion", libtcod.light_yellow, item = item_component)
            else:#Fireball scroll
                item_component = Item(use_function = cast_fireball)
                item = Object(x, y, "#", "scroll of fireball", libtcod.light_yellow, item = item_component)

            objects.append(item)
            item.send_to_back()

class Rect:
    #Rectangle on map to make room
    def __init__(self, x, y, x2, y2):
        self.x1 = x
        self.y1 = y
        self.x2 = x2
        self.y2 = y2

    def center(self):
        center_x = (self.x1 + self.x2) / 2
        center_y = (self.y1 + self.y2) / 2
        return (center_x, center_y)

    def intersect(self, other): #If intersect, return T
        return (self.x1 < other.x2 and self.x2 > other.x1 and \
            self.y1 < other.y2 and self.y2 > other.y1)
    def xDist(self, other):
        xChange1 = other.x2 - self.x1
        xChange2 = other.x1 - self.x2
        if abs(xChange2) > abs(xChange1):
            return xChange1
        else:
            return xChange2

    def yDist(self, other):
        yChange1 = other.y2 - self.y1
        yChange2 = other.y1 - self.y2
        if abs(yChange2) > abs(yChange1):
            return yChange1
        else:
            return yChange2

    def intersectY(self, other):
        return (self.y1 < other.y2 and self.y2 > other.y1)
    def intersectX(self,other):
        return (self.x1 < other.x2 and self.x2 > other.x1)